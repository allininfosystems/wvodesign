<?php

namespace Ess\M2ePro\Controller\Adminhtml\Amazon;

use Ess\M2ePro\Helper\Module;
use Magento\Backend\App\Action;

abstract class Simple extends \Ess\M2ePro\Controller\Adminhtml\Base
{
    //########################################

    //########################################
}